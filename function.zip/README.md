# lambda-sns-elasticsearch

When creating a lambda function you can upload this code as a .zip file. It is responsible to receive messages from SNS and forward them to ElasticSearch
